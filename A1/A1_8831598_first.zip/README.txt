Name: Nevin Wong Syum Ganesan
Student ID: 8831598
Section :Section C

Name: Nicholas Broadbent
Student ID: 8709720
Section: Section C

Description: ITI1121 Assignment 1, this archive contains the the 7 files, that is this file(README.txt),
the file  A1Q1.java, A1Q2.java, A1Q3.java, A1Q4.java, ArrayStringsTools.java, and StudentInfo.java.
